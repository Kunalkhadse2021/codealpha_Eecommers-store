# CodeAlpha Task 1 — Simple E-commerce Store

A beginner-friendly e-commerce website built with Django, SQLite, HTML, CSS and JavaScript.

## Features
- Product listing and product detail pages
- Session-based shopping cart (add, update quantity, remove)
- User registration, login and logout
- Checkout and order creation for logged-in users
- Order history
- Django admin for managing products and orders

## Requirements
- Python 3.10+
- pip

## Setup (Windows)
1. Extract the ZIP file.
2. Open Command Prompt / VS Code terminal in the project folder.
3. Create a virtual environment:
   ```bash
   py -m venv venv
   ```
4. Activate it:
   ```bash
   venv\Scripts\activate
   ```
5. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
6. Create database tables:
   ```bash
   python manage.py migrate
   ```
7. Create an admin account:
   ```bash
   python manage.py createsuperuser
   ```
8. Start the server:
   ```bash
   python manage.py runserver
   ```
9. Open http://127.0.0.1:8000/ in your browser.
10. Admin panel: http://127.0.0.1:8000/admin/

## Add products
Log in to `/admin/` using your superuser account. Add products with name, description, price, stock and an optional image URL. Products marked inactive are hidden from the store.

## GitHub repository
Create a repository named `CodeAlpha_EcommerceStore`. Upload the project files (do not upload `venv/` or `db.sqlite3`).

## Notes
- This is an educational starter project. Before real-world deployment, configure production secrets, HTTPS, secure cookies, payment gateway integration, stock locking, email verification and deployment settings.
- Checkout records an order in the local database; it does not charge a payment method.
