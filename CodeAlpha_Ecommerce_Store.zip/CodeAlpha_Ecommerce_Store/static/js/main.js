// Small client-side enhancement: confirm before removing a cart item.
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('form[action*="/cart/remove/"]').forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm("Remove this item from your cart?")) {
        event.preventDefault();
      }
    });
  });
});
