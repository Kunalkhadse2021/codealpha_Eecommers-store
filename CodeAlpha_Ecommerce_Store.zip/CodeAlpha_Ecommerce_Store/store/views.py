from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from .forms import RegisterForm, CheckoutForm
from .models import Product, Order, OrderItem


def _cart_details(request):
    cart = request.session.get("cart", {})
    items = []
    total = Decimal("0.00")
    for product_id, quantity in cart.items():
        try:
            product = Product.objects.get(pk=int(product_id), is_active=True)
            quantity = int(quantity)
        except (Product.DoesNotExist, ValueError, TypeError):
            continue
        if quantity < 1:
            continue
        line_total = product.price * quantity
        items.append({"product": product, "quantity": quantity, "line_total": line_total})
        total += line_total
    return items, total


def home(request):
    products = Product.objects.filter(is_active=True)
    return render(request, "store/home.html", {"products": products})


def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    return render(request, "store/product_detail.html", {"product": product})


def add_to_cart(request, product_id):
    if request.method != "POST":
        return redirect("home")
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    cart = request.session.get("cart", {})
    current_qty = int(cart.get(str(product_id), 0))
    if current_qty >= product.stock:
        messages.error(request, "Requested quantity is not available in stock.")
    elif product.stock <= 0:
        messages.error(request, "This product is out of stock.")
    else:
        cart[str(product_id)] = current_qty + 1
        request.session["cart"] = cart
        messages.success(request, f"{product.name} added to your cart.")
    return redirect("cart")


def cart_view(request):
    items, total = _cart_details(request)
    return render(request, "store/cart.html", {"items": items, "total": total})


def update_cart(request, product_id):
    if request.method == "POST":
        product = get_object_or_404(Product, pk=product_id, is_active=True)
        try:
            quantity = int(request.POST.get("quantity", "1"))
        except ValueError:
            quantity = 1
        cart = request.session.get("cart", {})
        if quantity <= 0:
            cart.pop(str(product_id), None)
        elif quantity <= product.stock:
            cart[str(product_id)] = quantity
        else:
            messages.error(request, f"Only {product.stock} item(s) are available.")
        request.session["cart"] = cart
    return redirect("cart")


def remove_from_cart(request, product_id):
    if request.method == "POST":
        cart = request.session.get("cart", {})
        cart.pop(str(product_id), None)
        request.session["cart"] = cart
        messages.success(request, "Item removed from cart.")
    return redirect("cart")


def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account has been created.")
            return redirect("home")
    else:
        form = RegisterForm()
    return render(request, "store/register.html", {"form": form})


@login_required
def checkout(request):
    items, total = _cart_details(request)
    if not items:
        messages.error(request, "Your cart is empty.")
        return redirect("cart")

    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                # Lock and validate current stock before creating the order.
                locked_products = {}
                for item in items:
                    product = Product.objects.select_for_update().get(pk=item["product"].pk)
                    if not product.is_active or product.stock < item["quantity"]:
                        messages.error(request, f"Insufficient stock for {product.name}. Please update your cart.")
                        return redirect("cart")
                    locked_products[product.pk] = product

                order = Order.objects.create(
                    user=request.user,
                    full_name=form.cleaned_data["full_name"],
                    email=form.cleaned_data["email"],
                    address=form.cleaned_data["address"],
                    total_amount=total,
                )
                for item in items:
                    product = locked_products[item["product"].pk]
                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        product_name=product.name,
                        price=product.price,
                        quantity=item["quantity"],
                    )
                    product.stock -= item["quantity"]
                    product.save(update_fields=["stock"])

            request.session["cart"] = {}
            messages.success(request, f"Order #{order.pk} placed successfully!")
            return redirect("order_history")
    else:
        form = CheckoutForm(initial={
            "full_name": request.user.get_full_name() or request.user.username,
            "email": request.user.email,
        })
    return render(request, "store/checkout.html", {"form": form, "items": items, "total": total})


@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "store/orders.html", {"orders": orders})
